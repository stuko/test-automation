package com.kcb.fds.jmeter;

public interface CassandraQueryTimeListener {
	public void applyQueryTime(String[][] data);
}
