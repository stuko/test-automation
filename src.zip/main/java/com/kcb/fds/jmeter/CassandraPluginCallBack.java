package com.kcb.fds.jmeter;

public interface CassandraPluginCallBack {
	public String call(String data);
}
