package com.auto.test.jmeter.plugin.common.function;

import java.util.Map;

@FunctionalInterface
public interface FileJsonArrayListFunction {
    public void read(String data);
}
