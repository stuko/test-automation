package com.auto.test.jmeter.plugin.common.function;

public interface TestPluginCallBack {
    String call(String data , long count);
}

