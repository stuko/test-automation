package com.auto.test.jmeter.plugin.common.function;

@FunctionalInterface
public interface TestPluginProgressBarCallBack {
    public int getValue();
}
