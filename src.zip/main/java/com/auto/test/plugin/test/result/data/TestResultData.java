/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.auto.test.plugin.test.result.data;

/**
 *
 * @author O218001_D
 */
public class TestResultData {
    
}
