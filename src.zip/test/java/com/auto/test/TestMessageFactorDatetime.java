package com.auto.test;

import org.junit.jupiter.api.Test;

public class TestMessageFactorDatetime {
    @Test
    void testFormatDatetime(){

    }
}
